function playSample(sampleName:any): void {
  let sample = document.getElementById(sampleName);
  sample.play();
}