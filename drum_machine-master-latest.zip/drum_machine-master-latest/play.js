
        window.onload = function () {
            const sound_files = [];
            sound_files[65] = "sounds/808_kick.wav";
            sound_files[83] = "sounds/clapnoize.wav";

            const kick = new Audio ("sounds/808_kick.wav");
            const clap = new Audio ("sounds/clapnoize.wav");

            const clap2 = new Audio ("sounds/808_clap.wav");
            const snare = new Audio ("sounds/808_snare.wav");

            const hihat = new Audio ("sounds/808_hihatclosed.wav");

            const playSample = (event) => {

                if (event.keyCode === 65) {
                   kick.play()
                }
    

                if (event.keyCode === 83) {
                    clap.play()
                }
    
 
                if (event.keyCode === 68) {
                    clap2.play()    
                }

    
                if (event.keyCode === 74) {
                    snare.play()  
                }

                if (event.keyCode === 74) {
                    hihat.play()  
                }
    
            }

        }


       